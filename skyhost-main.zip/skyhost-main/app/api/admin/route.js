import { NextRequest, NextResponse } from 'next/server'
import { db } from '../../../lib/db.ts'

export async function GET() {
  try {
    if (!db) {
      return NextResponse.json({
        totalVisitors: 0,
        activeChats: 0,
        conversionRate: 0,
        pageViews: 0
      })
    }
    
    const [analytics] = await db.execute('SELECT * FROM analytics ORDER BY id DESC LIMIT 1')
    const [leadsCount] = await db.execute('SELECT COUNT(*) as total FROM leads')
    const [newLeadsToday] = await db.execute('SELECT COUNT(*) as today FROM leads WHERE DATE(created_at) = CURDATE()')
    
    const data = analytics[0] || {}
    
    return NextResponse.json({
      totalVisitors: data.total_visitors || 0,
      activeChats: data.active_chats || 0,
      conversionRate: data.conversion_rate || 0,
      projectsCompleted: data.projects_completed || 0,
      totalLeads: leadsCount[0]?.total || 0,
      newLeadsToday: newLeadsToday[0]?.today || 0
    })
  } catch (error) {
    console.error('Analytics error:', error)
    return NextResponse.json({
      totalVisitors: 0,
      activeChats: 0,
      conversionRate: 0,
      pageViews: 0,
      totalLeads: 0,
      newLeadsToday: 0
    })
  }
}