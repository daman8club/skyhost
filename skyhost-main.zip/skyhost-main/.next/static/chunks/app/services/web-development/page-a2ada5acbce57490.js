(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[425],{2455:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return a}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).default)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},8956:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return a}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).default)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]])},4411:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return a}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).default)("Rocket",[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]])},2369:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return a}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).default)("Zap",[["polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2",key:"45s27k"}]])},6798:function(e,t,s){Promise.resolve().then(s.bind(s,8129))},8129:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return m}});var a=s(7437),l=s(732);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,s(2898).default)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);var c=s(4411),i=s(2455),r=s(8956),d=s(2369),x=s(1396),o=s.n(x);function m(){return(0,a.jsx)("div",{className:"min-h-screen pt-24 px-6",children:(0,a.jsxs)("div",{className:"max-w-4xl mx-auto",children:[(0,a.jsxs)(o(),{href:"/",className:"inline-flex items-center text-blue-400 hover:text-white mb-8 transition-colors",children:[(0,a.jsx)(n,{className:"w-4 h-4 mr-2"}),"Back to Home"]}),(0,a.jsxs)(l.motion.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"glass-card p-12",children:[(0,a.jsxs)("div",{className:"text-center mb-12",children:[(0,a.jsx)("div",{className:"w-20 h-20 bg-blue-400/20 rounded-2xl flex items-center justify-center mx-auto mb-6",children:(0,a.jsx)(c.default,{className:"w-10 h-10 text-blue-400"})}),(0,a.jsx)("h1",{className:"text-5xl font-black text-white mb-6",children:"Web Development"}),(0,a.jsx)("p",{className:"text-xl text-gray-300 max-w-2xl mx-auto",children:"Lightning-fast, responsive websites built with cutting-edge technology and optimized for performance"})]}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-8 mb-12",children:[(0,a.jsxs)("div",{className:"text-center",children:[(0,a.jsx)(i.default,{className:"w-8 h-8 text-blue-400 mx-auto mb-4"}),(0,a.jsx)("h3",{className:"text-xl font-bold text-white mb-2",children:"Modern Tech Stack"}),(0,a.jsx)("p",{className:"text-gray-400",children:"Next.js, React, TypeScript"})]}),(0,a.jsxs)("div",{className:"text-center",children:[(0,a.jsx)(r.default,{className:"w-8 h-8 text-blue-400 mx-auto mb-4"}),(0,a.jsx)("h3",{className:"text-xl font-bold text-white mb-2",children:"Global CDN"}),(0,a.jsx)("p",{className:"text-gray-400",children:"Lightning-fast worldwide"})]}),(0,a.jsxs)("div",{className:"text-center",children:[(0,a.jsx)(d.default,{className:"w-8 h-8 text-blue-400 mx-auto mb-4"}),(0,a.jsx)("h3",{className:"text-xl font-bold text-white mb-2",children:"Performance"}),(0,a.jsx)("p",{className:"text-gray-400",children:"99.9% uptime guarantee"})]})]}),(0,a.jsx)("div",{className:"text-center",children:(0,a.jsx)("button",{className:"btn-neon-primary",children:"Start Your Project"})})]})]})})}}},function(e){e.O(0,[206,396,971,938,744],function(){return e(e.s=6798)}),_N_E=e.O()}]);