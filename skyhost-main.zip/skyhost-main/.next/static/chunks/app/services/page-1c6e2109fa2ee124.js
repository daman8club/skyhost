(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[469],{8291:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},3966:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]])},2455:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},597:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("Palette",[["circle",{cx:"13.5",cy:"6.5",r:".5",key:"1xcu5"}],["circle",{cx:"17.5",cy:"10.5",r:".5",key:"736e4u"}],["circle",{cx:"8.5",cy:"7.5",r:".5",key:"clrty"}],["circle",{cx:"6.5",cy:"12.5",r:".5",key:"1s4xz9"}],["path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",key:"12rzf8"}]])},6714:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("Server",[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2",key:"ngkwjq"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2",key:"iecqi9"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6",key:"16zg32"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18",key:"nzw8ys"}]])},1271:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("Smartphone",[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]])},5790:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return n}});/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,i(2898).default)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]])},4711:function(e,t,i){Promise.resolve().then(i.bind(i,7138))},7138:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return y}});var n=i(7437),r=i(732),a=i(1396),s=i.n(a),l=i(2455),c=i(1271),o=i(5790),u=i(597),d=i(3966),p=i(6714),h=i(8291);function y(){let e=[{title:"Web Development",description:"Lightning-fast, responsive websites built with cutting-edge technology",icon:l.default,link:"/services/web-development",features:["Next.js","React","Performance Optimization"]},{title:"Mobile Apps",description:"Native and cross-platform mobile applications that deliver exceptional UX",icon:c.default,link:"/services/mobile-apps",features:["React Native","Flutter","iOS & Android"]},{title:"SEO & Marketing",description:"Data-driven marketing strategies that boost your online presence",icon:o.default,link:"/services/seo-marketing",features:["SEO Optimization","PPC Campaigns","Analytics"]},{title:"UI/UX Design",description:"Beautiful, intuitive designs that captivate users and enhance brand identity",icon:u.default,link:"/services/ui-ux-design",features:["User Research","Prototyping","Design Systems"]},{title:"AI Integration",description:"Cutting-edge AI solutions that automate processes and enhance experiences",icon:d.default,link:"/services/ai-integration",features:["Machine Learning","Chatbots","Automation"]},{title:"Cloud Solutions",description:"Scalable cloud infrastructure and deployment solutions for modern applications",icon:p.default,link:"/services/cloud-solutions",features:["AWS","DevOps","Scalability"]}];return(0,n.jsx)("div",{className:"min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white",children:(0,n.jsxs)("div",{className:"max-w-7xl mx-auto px-6 py-20",children:[(0,n.jsxs)(r.motion.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center mb-20",children:[(0,n.jsx)("h1",{className:"text-6xl font-black text-white mb-6",children:"Our Services"}),(0,n.jsx)("p",{className:"text-xl text-gray-300 max-w-3xl mx-auto",children:"Comprehensive digital solutions designed to accelerate your business growth and establish your competitive advantage in the NYC market."})]}),(0,n.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",children:e.map((e,t)=>(0,n.jsxs)(r.motion.div,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{delay:.1*t},className:"glass-card p-8 group hover:bg-white/10 transition-all duration-300",children:[(0,n.jsx)("div",{className:"w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-purple-500/30 transition-colors",children:(0,n.jsx)(e.icon,{className:"w-8 h-8 text-purple-400"})}),(0,n.jsx)("h3",{className:"text-2xl font-bold mb-4",children:e.title}),(0,n.jsx)("p",{className:"text-gray-300 mb-6",children:e.description}),(0,n.jsx)("div",{className:"flex flex-wrap gap-2 mb-6",children:e.features.map((e,t)=>(0,n.jsx)("span",{className:"px-3 py-1 bg-purple-500/20 rounded-full text-xs text-purple-300",children:e},t))}),(0,n.jsxs)(s(),{href:e.link,className:"text-cyan-400 font-semibold hover:text-cyan-300 transition-colors flex items-center group",children:["Learn More",(0,n.jsx)(h.default,{className:"ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform"})]})]},t))})]})})}}},function(e){e.O(0,[206,396,971,938,744],function(){return e(e.s=4711)}),_N_E=e.O()}]);